package com.example.microservicecommandes.commande.enteties;

import com.example.microservicecommandes.produit.enteties.Produit;
import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.Objects;

@Entity
public class Commande {

    @Id
    @GeneratedValue
    Long id;
    String description;
    int quantite;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    Date date;

    float montant;

    @ManyToOne
    @JoinColumn(name = "produit_id")
    private Produit produit; // Link to the Produit entity

    public Commande(String description, int quantite, Date date, float montant, Produit produit) {
        this.description = description;
        this.quantite = quantite;
        this.date = date;
        this.montant = montant;
        this.produit = produit;
    }

    public Commande() {
    }

    // Getters and setters for all fields
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    public float getMontant() {
        return montant;
    }

    public void setMontant(float montant) {
        this.montant = montant;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Produit getProduit() {
        return produit;
    }

    public void setProduit(Produit produit) {
        this.produit = produit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Commande commande = (Commande) o;
        return quantite == commande.quantite &&
                Float.compare(commande.montant, montant) == 0 &&
                Objects.equals(id, commande.id) &&
                Objects.equals(description, commande.description) &&
                Objects.equals(date, commande.date) &&
                Objects.equals(produit, commande.produit);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, description, quantite, date, montant, produit);
    }
}
