package com.example.microservicecommandes.commande.service;

import com.example.microservicecommandes.commande.enteties.Commande;
import com.example.microservicecommandes.commande.repo.CommandeRepository;
import com.example.microservicecommandes.produit.enteties.Produit;
import com.example.microservicecommandes.produit.repo.ProduitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CommandeService {

    private final CommandeRepository commandeRepository;
    private final ProduitRepository produitRepository;

    @Autowired
    public CommandeService(CommandeRepository commandeRepository, ProduitRepository produitRepository) {
        this.commandeRepository = commandeRepository;
        this.produitRepository = produitRepository;
    }

    public List<Commande> getAllCommandes() {
        try {
            return commandeRepository.findAll();
        } catch (Exception e) {
            System.out.println("Error fetching commandes: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public Optional<Commande> getCommandeById(Long id) {
        try {
            return commandeRepository.findById(id);
        } catch (Exception e) {
            System.out.println("Error fetching commande by ID: " + e.getMessage());
            return Optional.empty();
        }
    }

    public Commande saveOrUpdateCommande(Commande commande, Long produitId) {
        try {
            // Find the product by ID
            Optional<Produit> produit = produitRepository.findById(produitId);
            if (produit.isPresent()) {
                commande.setProduit(produit.get()); // Associate produit with commande
            }
            return commandeRepository.save(commande);
        } catch (Exception e) {
            System.out.println("Error saving/updating commande: " + e.getMessage());
            return new Commande(); // Fallback value
        }
    }

    public void deleteCommande(Long id) {
        try {
            commandeRepository.deleteById(id);
        } catch (Exception e) {
            System.out.println("Error deleting commande: " + e.getMessage());
        }
    }
}
