package com.example.aditional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AditionalApplication {

    public static void main(String[] args) {
        SpringApplication.run(AditionalApplication.class, args);
    }

}
