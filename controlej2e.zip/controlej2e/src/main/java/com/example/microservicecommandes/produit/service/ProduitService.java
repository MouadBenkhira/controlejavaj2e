package com.example.microservicecommandes.produit.service;

import com.example.microservicecommandes.produit.enteties.Produit;
import com.example.microservicecommandes.produit.repo.ProduitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProduitService {

    @Autowired
    private ProduitRepository produitRepository;

    // Add a new product
    public Produit addProduit(Produit produit) {
        return produitRepository.save(produit);
    }

    // Update an existing product
    public Produit updateProduit(Long id, Produit produit) {
        if (produitRepository.existsById(id)) {
            produit.setId(id);
            return produitRepository.save(produit);
        }
        return null; // or throw an exception
    }

    // Get all products
    public List<Produit> getAllProduits() {
        return produitRepository.findAll();
    }

    // Get a product by id
    public Optional<Produit> getProduitById(Long id) {
        return produitRepository.findById(id);
    }

    // Delete a product
    public void deleteProduit(Long id) {
        produitRepository.deleteById(id);
    }
}
