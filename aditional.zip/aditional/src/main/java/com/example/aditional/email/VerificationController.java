package com.example.aditional.email;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/verification")
public class VerificationController {

    private final VerificationService verificationService;

    public VerificationController(VerificationService verificationService) {
        this.verificationService = verificationService;
    }

    // Endpoint to generate a verification code and send it via email
    @PostMapping("/generate")
    public ResponseEntity<String> generateCode(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        if (email == null || email.isEmpty()) {
            return ResponseEntity.badRequest().body("email is required.");
        }
        try {
            verificationService.generateCode(email);
            return ResponseEntity.ok("Verification code sent to " + email);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Failed to send verification code: " + e.getMessage());
        }
    }


    // Endpoint to verify the provided code
    @PostMapping("/verify")
    public ResponseEntity<String> verifyCode(@RequestParam String email, @RequestParam String code) {
        boolean isValid = verificationService.verifyCode(email, code);
        // In the VerificationController:
        if (isValid) {
            return ResponseEntity.ok("The verification code has been successfully validated. You may proceed.");
        } else {
            return ResponseEntity.status(400).body("Invalid or expired code.");
        }

    }
}
