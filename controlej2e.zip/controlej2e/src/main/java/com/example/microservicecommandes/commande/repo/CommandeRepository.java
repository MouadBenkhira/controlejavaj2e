package com.example.microservicecommandes.commande.repo;

import com.example.microservicecommandes.commande.enteties.Commande;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CommandeRepository extends JpaRepository<Commande, Long> {
    List<Commande> findTop10ByOrderByDateDesc();
}

