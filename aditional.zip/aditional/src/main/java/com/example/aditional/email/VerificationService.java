package com.example.aditional.email;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@Service
public class VerificationService {

    private final Map<String, VerificationCode> codeStore = new HashMap<>();
    private final JavaMailSender mailSender;

    @Autowired
    public VerificationService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    // Generate a random verification code
    public String generateCode(String email) {
        String code = String.format("%06d", new Random().nextInt(999999)); // 6-digit code
        codeStore.put(email, new VerificationCode(code, System.currentTimeMillis()));

        // Send the code via email
        try {
            sendEmail(email, code);
        } catch (MessagingException e) {
            e.printStackTrace();
            // Handle exception if email sending fails
        }

        return code;
    }

    // Send an HTML formatted email
    private void sendEmail(String email, String code) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        helper.setTo(email);
        helper.setSubject("Your Verification Code");

        String htmlContent = buildHtmlContent(code);
        helper.setText(htmlContent, true); // Set to true to send as HTML

        mailSender.send(message);
        System.out.println("Email sent to " + email);
    }

    // Build HTML content for the email
    private String buildHtmlContent(String verificationCode) {
        return String.format("""
           <!DOCTYPE html>
           <html lang="en">
           <head>
               <meta charset="UTF-8">
               <meta name="viewport" content="width=device-width, initial-scale=1.0">
               <title>Verification Code</title>
               <style>
                   body {
                       font-family: Arial, sans-serif;
                       background-color: #f9f9f9;
                       margin: 0;
                       padding: 0;
                   }
                   .email-container {
                       max-width: 600px;
                       margin: 20px auto;
                       background-color: #ffffff;
                       border-radius: 8px;
                       box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                       overflow: hidden;
                   }
                   .email-header {
                       background-color: #007bff;
                       color: #ffffff;
                       text-align: center;
                       padding: 20px;
                       font-size: 24px;
                   }
                   .email-body {
                       padding: 20px;
                       color: #333333;
                       line-height: 1.6;
                   }
                   .verification-code {
                       font-size: 20px;
                       font-weight: bold;
                       color: #007bff;
                       text-align: center;
                       margin: 20px 0;
                   }
               </style>
           </head>
           <body>
               <div class="email-container">
                   <div class="email-header">
                       Verification Code
                   </div>
                   <div class="email-body">
                       <p>Dear User,</p>
                       <p>We have received a request to verify your email address. Please use the following verification code to complete the process:</p>
                       <p class="verification-code">%s</p>
                       <p>If you did not request this, please ignore this email.</p>
                       <p>Thank you,<br>The Team</p>
                   </div>
               </div>
           </body>
           </html>
           """, verificationCode); // This is where the verificationCode is inserted.
    }

    // Verify the code
    public boolean verifyCode(String email, String code) {
        VerificationCode storedCode = codeStore.get(email);

        if (storedCode == null) {
            return false; // No code generated for this email
        }

        // Check if the code matches and is not expired
        boolean isValid = storedCode.getCode().equals(code) &&
                (System.currentTimeMillis() - storedCode.getTimestamp()) < TimeUnit.MINUTES.toMillis(5);

        if (isValid) {
            codeStore.remove(email); // Invalidate the code after successful verification
        }

        return isValid;
    }

    // Helper class to store verification code details
    private static class VerificationCode {
        private final String code;
        private final long timestamp;

        public VerificationCode(String code, long timestamp) {
            this.code = code;
            this.timestamp = timestamp;
        }

        public String getCode() {
            return code;
        }

        public long getTimestamp() {
            return timestamp;
        }
    }
}
