    package com.example.aditional.user.service;

    import com.example.aditional.user.User;
    import com.example.aditional.user.repo.UserRepository;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
    import org.springframework.stereotype.Service;

    import java.util.Optional;

    @Service
    public class UserService {
        private final UserRepository userRepository;
        private final BCryptPasswordEncoder passwordEncoder;

        @Autowired
        public UserService(UserRepository userRepository) {
            this.userRepository = userRepository;
            this.passwordEncoder = new BCryptPasswordEncoder();  // Password encoder
        }

        public User register(User user) {
            // Check if the email is already in use
            if (userRepository.findByEmail(user.getEmail()).isPresent()) {
                throw new RuntimeException("Email is already in use.");
            }

            // Encrypt the password before saving
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            return userRepository.save(user);
        }

        public User login(String email, String password) {
            Optional<User> optionalUser = userRepository.findByEmail(email);

            if (optionalUser.isPresent()) {
                User user = optionalUser.get();

                // Check if the password matches
                if (passwordEncoder.matches(password, user.getPassword())) {
                    return user;
                } else {
                    throw new RuntimeException("Invalid credentials.");
                }
            } else {
                throw new RuntimeException("User not found.");
            }
        }
    }
