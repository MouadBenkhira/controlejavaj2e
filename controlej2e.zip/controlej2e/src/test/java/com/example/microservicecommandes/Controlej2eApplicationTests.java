package com.example.microservicecommandes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Controlej2eApplicationTests {

    @Test
    void contextLoads() {
    }

}
