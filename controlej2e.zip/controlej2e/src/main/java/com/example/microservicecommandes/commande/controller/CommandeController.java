package com.example.microservicecommandes.commande.controller;

import com.example.microservicecommandes.commande.enteties.Commande;
import com.example.microservicecommandes.commande.service.CommandeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/commandes")

public class CommandeController {

    @Autowired
    private CommandeService commandeService;

    @GetMapping
    public List<Commande> getAllCommandes() {
        return commandeService.getAllCommandes();
    }

    @GetMapping("/{id}")
    public Commande getCommandeById(@PathVariable Long id) {
        return commandeService.getCommandeById(id)
                .orElseGet(() -> fallbackGetCommandeById(id));
    }

    // Save or update commande and link it to a produit
    @PostMapping("/save")
    public Commande saveOrUpdateCommande(@RequestBody Commande commande, @RequestParam Long produitId) {
        return commandeService.saveOrUpdateCommande(commande, produitId);
    }

    @DeleteMapping("/{id}")
    public void deleteCommande(@PathVariable Long id) {
        commandeService.deleteCommande(id);
    }

    private Commande fallbackGetCommandeById(Long id) {
        System.out.println("Fallback triggered for getCommandeById: " + id);
        return new Commande();
    }
}
