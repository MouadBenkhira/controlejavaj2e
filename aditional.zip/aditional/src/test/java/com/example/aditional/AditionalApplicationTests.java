package com.example.aditional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AditionalApplicationTests {

    @Test
    void contextLoads() {
    }

}
